#ifndef __GPMAIN_H__
#define __GPMAIN_H__

void HandleInput(  );

void GpMain( void *arg );
void Init(  );
void GameEngine(  );

int nflip;
GP_HPALETTE h_pal;

GPDRAWSURFACE gpDraw[ 2 ];	/* buffers */

#endif
