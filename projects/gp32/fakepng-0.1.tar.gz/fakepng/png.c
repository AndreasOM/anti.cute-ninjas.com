#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <zlib.h>

#include <png.h>


unsigned long png_ntohl( unsigned long in )
{
	unsigned long	out;
	unsigned char	*src = ( unsigned char* )&in;
	unsigned char *dst = ( unsigned char* )&out;
	
	dst[ 0 ] = src[ 3 ];
	dst[ 1 ] = src[ 2 ];
	dst[ 2 ] = src[ 1 ];
	dst[ 3 ] = src[ 0 ];
	
	return( out );
}

png_t *png_new( )
{
	png_t	*pPng = NULL;
	
	pPng = ( png_t* )malloc( sizeof( png_t ) );
	pPng->pcIHDR = NULL;
	pPng->ppcIDAT = ( png_chunk_t** )malloc( sizeof( png_chunk_t* )*1024 );	/* this should be dynamic, but who cares */
	pPng->iNumIDAT = 0;
	
	pPng->pIHDR = ( png_IHDR_t* )malloc( sizeof( png_IHDR_t ) );
	pPng->pPLTE = ( png_PLTE_t* )malloc( sizeof( png_PLTE_t ) );			/* this is optional, but who cares*/
	pPng->pIDAT = NULL;
        
	return( pPng );
}


png_chunk_t* png_chunkNext( png_memfile_t *pmf )
{
	png_chunk_t	*pChunk = NULL;
	
	if( pmf->iPos+4>pmf->iSize ){	/* check if we still have a chunk */
		return( NULL );
	}
	pChunk = ( png_chunk_t* )malloc( sizeof( png_chunk_t ) );
	
	memcpy( &pChunk->length, pmf->pData+pmf->iPos, 4 );
	pmf->iPos += 4;
	
	pChunk->length = png_ntohl( pChunk->length );	/* replace me for easier porting */
	
	memcpy( &pChunk->type, pmf->pData+pmf->iPos, 4 );
	pmf->iPos += 4;
	
	pChunk->type[ 4 ] = 0;
	if( pChunk->length > 0 ){
		pChunk->pData = ( void* )malloc( pChunk->length );
		/* FIXME: no need to copy the data here */
		memcpy( pChunk->pData, pmf->pData+pmf->iPos, pChunk->length );
		pmf->iPos += pChunk->length;
	}else{
		pChunk->pData = NULL;
	}
	memcpy( &pChunk->crc, pmf->pData+pmf->iPos, 4 );
	pmf->iPos += 4;
	/*printf( "%08X\n", *( unsigned long int* )( pChunk->type ) );*/
	if( !memcmp( "IDAT", pChunk->type, 4 ) ){
		pChunk->bType = PNG_TYPE_IDAT;
	}else if( !memcmp( "IHDR", pChunk->type, 4 ) ){
		pChunk->bType = PNG_TYPE_IHDR;
	}else if( !memcmp( "IEND", pChunk->type, 4 ) ){
		pChunk->bType = PNG_TYPE_IEND;
	}else if( !memcmp( "PLTE", pChunk->type, 4 ) ){
		pChunk->bType = PNG_TYPE_PLTE;
	}else{
		pChunk->bType = PNG_TYPE_UNKNOWN;
	}
	
	
	return( pChunk );
}


int png_addIHDRFromChunk( png_t *pPng, png_chunk_t *pc )
{
	pPng->pIHDR->width = png_ntohl( ( ( unsigned long int* ) pc->pData )[ 0 ] );
	pPng->pIHDR->height = png_ntohl( ( ( unsigned long int* ) pc->pData )[ 1 ] );
	
	pPng->pIHDR->bitDepth = ( ( ( unsigned char* ) pc->pData )[ 8 ] );
	pPng->pIHDR->colorType = ( ( ( unsigned char* ) pc->pData )[ 9 ] );
	pPng->pIHDR->compressionMethod = ( ( ( unsigned char* ) pc->pData )[ 10 ] );
	pPng->pIHDR->filterMethod = ( ( ( unsigned char* ) pc->pData )[ 11 ] );
	pPng->pIHDR->interlaceMethod = ( ( ( unsigned char* ) pc->pData )[ 12 ] );
	
	return( 0 );
}

int png_addPLTEFromChunk( png_t *pPng, png_chunk_t *pc )
{
	pPng->pPLTE->num = ( pc->length/3.0 )-1;
	memcpy( pPng->pPLTE->data, pc->pData, ( pPng->pPLTE->num+1 )*3 );
	
	return( 0 );
}

int png_addIDATFromChunk( png_t *pPng, png_chunk_t *pc )
{
	unsigned char	*pDest = NULL;
	int		i;
	
	if( !pPng->pIDAT ){	/* this is the first call */
		pPng->pIDAT = ( png_IDAT_t* )malloc( sizeof( png_IDAT_t ) );
		i = pPng->pIHDR->width*pPng->pIHDR->height*pPng->pIHDR->bitDepth/8; /* this is too much, but we don't bother with realloc, for now */
		pPng->pIDAT->pData = ( void* )malloc( i );
		pPng->pIDAT->size = 0;
	}
	pDest = pPng->pIDAT->pData;
	pDest += pPng->pIDAT->size;
	i = pc->length;
	memcpy( pDest, pc->pData, i );
	pPng->pIDAT->size += i;
	
	return( 0 );
}

int png_decompress( png_t *pPng )
{
	int	                lines;
	int	                line = 0;
	int                     length;
	int     	        rc = 0;
	unsigned long int	size = 0;
	unsigned char   	*pDest = NULL;
	
	lines = pPng->pIHDR->height;
	length = pPng->pIHDR->width;
	if( pPng->pIHDR->bitDepth == 16 ){
		length *= 2;
	}
	switch( pPng->pIHDR->colorType ){
		case 0:
			break;
		case 2:
			length *= 3;	/* RGB triplets */
			break;
		case 3:
			break;
		case 4:
			length *= 2;	/* grayscale + alpha */
			break;
		case 6:
			length *= 4;	/* RGB + alpha */
			break;
		default:		/* oh'oh */
			break;
	}
			
	length ++;
	
	
	pPng->pScanlines = ( unsigned char* )malloc( lines*length );
	
	size = lines*length;
	rc = uncompress( pPng->pScanlines, &size, pPng->pIDAT->pData, pPng->pIDAT->size );
	
	if( rc == Z_DATA_ERROR ){
		printf( "CRITICAL: zlib returned error\n" );
		return( -1 );
        }

	pPng->iSize = ( length-1 )*lines;
	pPng->pData = ( unsigned char* )malloc( lines*( length-1 ) ); /* we don't need the filter type here */
	pDest = pPng->pData;
	while( line<lines ){
		switch( pPng->pScanlines[ length*line ] ){
			case 0:
				memcpy( pDest, pPng->pScanlines+( length*line+1 ), length-1 );
				break;
			default:
				printf( "Filter %d for line %d not supported ... yet.\n", pPng->pScanlines[ length*line ], line );
				return( -1 );
				break;
		}
		pDest += length-1;
		line++;
	}
	
	return( 0 );
}

int png_GP32Palette( png_t *pp )
{
        int i=0;
        unsigned short r,g,b;
        unsigned short col;
        
        if( pp->pPLTE ){
               while( i<=pp->pPLTE->num ){
                       r = pp->pPLTE->data[ i*3+0 ];
                       g = pp->pPLTE->data[ i*3+1 ];
                       b = pp->pPLTE->data[ i*3+2 ];
                       col = ( ( r>>3 )<<11 )|( ( g>>3 )<<6 )|( ( b>>3 )<<1 )|1;
                       pp->gp32Pal[ i ] = col;
                       i++;
               }                       
        }
        pp->gp32PalNum = pp->pPLTE->num;
        return( 0 );
}

png_t *png_loadFromMem( png_memfile_t *pmf )
{
	png_t	*pp = NULL;
	unsigned char	pngSig[ 8 ]	= { 137, 80, 78, 71, 13, 10, 26, 10 };
	png_chunk_t	*pNewChunk	= NULL;

	if( memcmp( pmf->pData+pmf->iPos, pngSig, 8 ) ){	/* invalid signature */
		return( NULL );
	}
	pmf->iPos += 8;
	
	pp = png_new( );
	pNewChunk = png_chunkNext( pmf );
	do{
		switch( pNewChunk->bType ){
			case PNG_TYPE_IDAT:
				png_addIDATFromChunk( pp, pNewChunk );
				break;
			case PNG_TYPE_IHDR:
				png_addIHDRFromChunk( pp, pNewChunk );
				break;
			case PNG_TYPE_IEND:
				break;
			case PNG_TYPE_PLTE:
				png_addPLTEFromChunk( pp, pNewChunk );
				break;
			case PNG_TYPE_UNKNOWN:
				/*printf( "UNKNOWN chunk type >>%s<<\n", pNewChunk->type );*/
				break;
			default:
				break;
		}
	} while( ( pNewChunk = png_chunkNext( pmf ) ) );
	
	png_decompress( pp );
        png_GP32Palette( pp );
	
	return( pp );
}

png_t *png_loadFromFile( char *pszFilename )
{
	png_memfile_t	*pmf = NULL;
	FILE		*pf = NULL;

	/* we could mmap the file, but that's not as portable as reading it the old fashioned way */
	
	pf = fopen( pszFilename, "rb" );
	fseek( pf, 0, SEEK_END );
	pmf = ( png_memfile_t* )malloc( sizeof( png_memfile_t ) );
	pmf->iSize = ftell( pf );
        pmf->iPos = 0;
	fseek( pf, 0, SEEK_SET );
	
	pmf->pData = ( unsigned char* )malloc( pmf->iSize );
	
	fread( ( void* )pmf->pData, 1, pmf->iSize, pf );
	
	fclose( pf );
	
	return( png_loadFromMem( pmf ) );
}
