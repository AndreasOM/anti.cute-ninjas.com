#ifndef __PNG_H
#define __PNG_H

#define	PNG_TYPE_UNKNOWN	0
#define	PNG_TYPE_IHDR		1
#define	PNG_TYPE_IDAT		2
#define	PNG_TYPE_PLTE		3
#define	PNG_TYPE_IEND		255

typedef struct {
	unsigned long int	length;
	unsigned char		type[ 4+1 ];	/* official 4 byte code, plus one so we can print it */
	unsigned char		bType;		/* private shortcut */
	unsigned short int	pos;		/* position in file */
	void*			pData;
	unsigned long int	crc;
} png_chunk_t;

typedef struct {
	unsigned long int	width;
	unsigned long int	height;
	unsigned char		bitDepth;
	unsigned char		colorType;
	unsigned char		compressionMethod;
	unsigned char		filterMethod;
	unsigned char		interlaceMethod;
} png_IHDR_t;

typedef struct {
	void			*pData;
	int			size;
} png_IDAT_t;

typedef struct {
	unsigned char		data[ 256*3 ];	/* this is the maximum anyway */
	unsigned char		num;			/* number of entries minus on, so '0' is one entry */
} png_PLTE_t;

typedef struct {
	png_chunk_t		*pcIHDR;
	png_chunk_t		**ppcIDAT;
	unsigned short int	iNumIDAT;
	png_IHDR_t		*pIHDR;
	png_IDAT_t		*pIDAT;
	png_PLTE_t		*pPLTE;
	unsigned char		*pScanlines;
	unsigned char		*pData;
	unsigned long int	iSize;
        unsigned short          gp32Pal[ 256 ];
        unsigned char           gp32PalNum;
} png_t;

typedef struct {
	unsigned char	*pData;
	long int	iSize;
	long int	iPos;
} png_memfile_t;

png_t *png_loadFromFile( char *pszFilename );
png_t *png_loadFromMem( png_memfile_t *pmf );
void png_printInfo( png_t *pp );
int png_saveRAW( png_t *pPng, char *pszFilename );

#endif
