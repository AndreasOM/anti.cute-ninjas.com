#include <stdlib.h>
#include <stdio.h>
/*#include <math.h>*/
#include "gpdef.h"
#include "gpstdlib.h"
#include "gpgraphic.h"
#include "gpmain.h"
#include "gpstdio.h"
#include "gpfont.h"

#include "sintab.h"

#include <png.h>

typedef struct{
                void    *data;
                long int     size;
}data_t;
extern data_t   *dataDataFake;
extern void     *dataDataFake_data;
extern long     dataDataFake_size;


png_t   *ppFake = NULL;

/*
        p1.dx = ( ( sintab[ p1.dir ]-128.0 )/128.0 )*p1.vel*0.2;
        p1.dy = ( ( sintab[ p1.dir+64 ]-128.0 )/128.0 )*p1.vel*0.2;
        p1.dy *= -1;
*/


void GpMain( void *arg )
{
	Init(  );
	GameEngine(  );
}

void Init(  )
{
	int i;
        png_memfile_t   mf;
        GpClockSpeedChange( 40000000, 0x48013, 1 );
        
	nflip = 1;

	for( i = 0; i < 2; i++ ) {
		GpLcdSurfaceGet( &gpDraw[i], i );
	}
	GpRectFill( NULL, &gpDraw[nflip], 0, 0, gpDraw[nflip].buf_w,
		    gpDraw[nflip].buf_h, 0xff );

        /* LOAD the PNG */
        mf.pData = ( unsigned char* )&dataDataFake->data;
        mf.iSize = dataDataFake_size;
        mf.iPos = 0;
        ppFake = png_loadFromMem( &mf );
                
        h_pal = GpPaletteCreate( ppFake->gp32PalNum, ( GP_PALETTEENTRY * ) ppFake->gp32Pal );
	GpPaletteSelect( h_pal );
	GpPaletteRealize(  );
	GpPaletteDelete( h_pal );
	h_pal = NULL;

	GpSurfaceSet( &gpDraw[0] );
}
 
void GameEngine(  )
{
        int     ax=25;
        int     x;
        
	while( 1 ) {
		GpRectFill( NULL, &gpDraw[nflip], 0, 0, gpDraw[nflip].buf_w,
			    gpDraw[nflip].buf_h, 0x00 );

                
                GpBitBlt( NULL, &gpDraw[nflip], 0, 0,
                        320, 240,
                        ( unsigned char * ) ppFake->pData,
                        0, 0,
                        320,240 );
                x = sintab[ ax ]*0.8+20;
		GpTextOut( NULL, &gpDraw[nflip], x, 60, "anti^fake", 113 );
		GpTextOut( NULL, &gpDraw[nflip], x-1, 59, "anti^fake", 41 );
		GpTextOut( NULL, &gpDraw[nflip], 6, 6, "t'is just a 20 minute png loader hack", 113 );
		GpTextOut( NULL, &gpDraw[nflip], 5, 5, "t'is just a 20 minute png loader hack", 41 );
		GpSurfaceFlip( &gpDraw[nflip++] );
		nflip &= 0x01;
                
                ax++;
                ax&=255;
	}
}
